import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'
import { loadCollection } from '../lib/content'

export default function Contact(){
  const settings = loadCollection('/content/settings/*.md')[0] || {}
  return (
    <>
      <Header/>
      <main className="container py-10">
        <h1 className="text-4xl font-bold mb-6">Contact</h1>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="card p-5">
            <p><strong>Phone:</strong> {settings.phone || '+1 (555) 123-4567'}</p>
            <p><strong>Email:</strong> {settings.email || 'hello@example.com'}</p>
            <p><strong>Address:</strong> {settings.address || '123 Vanity Lane, City'}</p>
          </div>
          <div className="card p-2">
            <iframe title="map" src="https://maps.google.com/maps?q=New%20York&t=&z=13&ie=UTF8&iwloc=&output=embed" className="w-full h-64 rounded-xl"></iframe>
          </div>
        </div>
      </main>
      <Footer/>
    </>
  )
}
