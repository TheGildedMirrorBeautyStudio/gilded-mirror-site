import { createClient } from '@supabase/supabase-js'
import { createEvent } from 'ics'
import { Resend } from 'resend'

const SUPABASE_URL = process.env.SUPABASE_URL
const SUPABASE_SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE
const resendApiKey = process.env.RESEND_API_KEY
const SITE_URL = process.env.SITE_URL || 'http://localhost:5173'
const BOOKING_FROM = process.env.BOOKING_FROM || 'Gilded Mirror <bookings@example.com>'

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ message: 'Method not allowed' }) }
  }

  // If Supabase is not configured, fail gracefully so the UI still works for demo
  if(!SUPABASE_URL || !SUPABASE_SERVICE_ROLE){
    return { statusCode: 200, body: JSON.stringify({ demo: true, message: 'Supabase not configured; booking accepted in demo mode.' }) }
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE)

  try {
    const data = JSON.parse(event.body || '{}')
    const { service, staff, start, end, customer, source } = data

    // Insert client if not exists (naive by email)
    let clientId = null
    if(customer?.email){
      const { data: existing } = await supabase.from('clients').select('id').eq('email', customer.email).maybeSingle()
      if(existing?.id){ clientId = existing.id }
      else{
        const { data: inserted, error: cErr } = await supabase.from('clients').insert({ name: customer.name, email: customer.email, phone: customer.phone }).select('id').single()
        if(cErr) throw cErr
        clientId = inserted.id
      }
    }

    // Insert appointment
    const { data: appt, error } = await supabase.from('appointments').insert({
      service_title: service?.title, service_slug: service?.slug, service_duration: service?.duration, service_price: service?.price,
      staff_name: staff?.name || 'Any', start, end, client_id: clientId, customer_name: customer?.name, customer_email: customer?.email, customer_phone: customer?.phone, status: 'booked', source: source || 'web'
    }).select('*').single()
    if(error) throw error

    // Prepare ICS calendar invite
    const startDt = new Date(start)
    const endDt = new Date(end)
    const toArr = (d) => [d.getUTCFullYear(), d.getUTCMonth()+1, d.getUTCDate(), d.getUTCHours(), d.getUTCMinutes()]
    const icsRes = await new Promise((resolve, reject)=>{
      createEvent({
        title: `${service?.title || 'Appointment'} — The Gilded Mirror`,
        start: toArr(startDt),
        end: toArr(endDt),
        description: `Service: ${service?.title}\nDuration: ${service?.duration} min\nPrice: ${service?.price || ''}`,
        organizer: { name: 'The Gilded Mirror', email: (BOOKING_FROM.match(/<(.+?)>/) || [])[1] || 'bookings@example.com' },
        url: SITE_URL,
      }, (err, value) => err ? reject(err) : resolve(value))
    })
    const icsBase64 = Buffer.from(icsRes).toString('base64')

    // Send email via Resend if configured
    if(resendApiKey && customer?.email){
      const resend = new Resend(resendApiKey)
      await resend.emails.send({
        from: BOOKING_FROM,
        to: customer.email,
        subject: `Booking confirmed — ${service?.title}`,
        text: `Hi ${customer?.name || ''},\n\nYour booking is confirmed.\n\nService: ${service?.title}\nDate: ${new Date(start).toLocaleString()}\nDuration: ${service?.duration} min\n\nSee you soon!\nThe Gilded Mirror`,
        attachments: [{ filename: 'booking.ics', content: icsBase64 }],
      })
    }

    return { statusCode: 200, body: JSON.stringify({ ok: true, id: appt?.id }) }
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ message: e.message }) }
  }
}
