import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = process.env.SUPABASE_URL
const SUPABASE_SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE
const ADMIN_API_KEY = process.env.ADMIN_API_KEY

export const handler = async (event) => {
  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, body: JSON.stringify({ message: 'Method not allowed' }) }
  }

  // optional simple auth: require header x-admin-key if you want to hide data
  const key = event.headers['x-admin-key']
  if(ADMIN_API_KEY && key !== ADMIN_API_KEY){
    return { statusCode: 401, body: JSON.stringify({ message: 'Unauthorized' }) }
  }

  if(!SUPABASE_URL || !SUPABASE_SERVICE_ROLE){
    return { statusCode: 200, body: JSON.stringify({ items: [] }) }
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE)

  try {
    const params = event.queryStringParameters || {}
    const date = params.date // YYYY-MM-DD optional
    let query = supabase.from('appointments').select('*').order('start', { ascending: true }).limit(200)
    if(date){
      query = query.gte('start', date + 'T00:00:00').lte('start', date + 'T23:59:59')
    }
    const { data, error } = await query
    if(error) throw error
    return { statusCode: 200, body: JSON.stringify({ items: data || [] }) }
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ message: e.message }) }
  }
}
