import React from 'react'
import AdminGate from '../../lib/AdminGate.jsx'
import { BarChart, Bar, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, CartesianGrid } from 'recharts'
import { Home, Calendar, Users, Scissors, PieChart as PieIcon, Settings, Bell, LogOut, Search, PlusCircle, Sparkles } from 'lucide-react'

const BRAND = {
  bg: '#0a0a0a',
  panel: '#121212',
  card: '#171717',
  border: '#242424',
  brand: '#ff007f',
  text: '#f6f1ea',
  subtext: '#d6d0c9',
}

const statCards = [
  { label: "Today's Bookings", value: 18, delta: "+3", icon: <Calendar size={18}/> },
  { label: "New Clients", value: 6, delta: "+2", icon: <Users size={18}/> },
  { label: "Revenue (₹)", value: "23,450", delta: "+12%", icon: <Sparkles size={18}/> },
  { label: "No-show Risk", value: "2", delta: "-1", icon: <Bell size={18}/> },
]

const inquiriesPerMonth = [
  { m: 'Jan', v: 8 },{ m: 'Feb', v: 14 },{ m: 'Mar', v: 11 },{ m: 'Apr', v: 17 },{ m: 'May', v: 20 },{ m: 'Jun', v: 25 },{ m: 'Jul', v: 22 },{ m: 'Aug', v: 19 },{ m: 'Sep', v: 28 },{ m: 'Oct', v: 32 },{ m: 'Nov', v: 30 },{ m: 'Dec', v: 24 }
]

const incomePerMonth = [
  { m: 'Jan', v: 9000 },{ m: 'Feb', v: 21000 },{ m: 'Mar', v: 32000 },{ m: 'Apr', v: 27000 },{ m: 'May', v: 35000 },{ m: 'Jun', v: 30000 },{ m: 'Jul', v: 38000 },{ m: 'Aug', v: 36000 },{ m: 'Sep', v: 42000 },{ m: 'Oct', v: 47000 },{ m: 'Nov', v: 44000 },{ m: 'Dec', v: 39000 }
]

const sourceBreakdown = [
  { name: 'Web', v: 60 },{ name: 'Instagram', v: 18 },{ name: 'WhatsApp', v: 12 },{ name: 'Referral', v: 10 }
]

const pieColors = ['#ff007f', '#9b5dff', '#49c5b6', '#ffd166']

function Sidebar() {
  const Item = ({ icon, label, active=false }) => (
    <a className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${active?'bg-[#171717] text-white':'text-[#d6d0c9] hover:bg-[#171717]'}`} href="#">
      {icon}
      <span className="text-sm font-medium">{label}</span>
    </a>
  );
  return (
    <aside style={{background: BRAND.panel}} className="hidden md:flex w-64 flex-col border-r" >
      <div className="p-5 border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-full" style={{background: BRAND.brand}}/>
          <div>
            <p className="font-semibold leading-tight" style={{color: BRAND.text}}>Gilded Mirror</p>
            <p className="text-xs" style={{color: BRAND.subtext}}>Admin</p>
          </div>
        </div>
      </div>
      <nav className="p-3 space-y-1">
        <Item icon={<Home size={18}/>} label="Dashboard" active />
        <Item icon={<Calendar size={18}/>} label="Appointments" />
        <Item icon={<Users size={18}/>} label="Clients" />
        <Item icon={<Scissors size={18}/>} label="Services" />
        <Item icon={<PieIcon size={18}/>} label="Reports" />
        <Item icon={<Settings size={18}/>} label="Settings" />
      </nav>
      <div className="mt-auto p-3">
        <a className="flex items-center gap-3 px-4 py-3 rounded-xl" style={{color: BRAND.subtext}} href="#"><LogOut size={18}/> Log out</a>
      </div>
    </aside>
  );
}

function Topbar(){
  return (
    <header className="flex items-center gap-4 px-4 md:px-8 h-16 border-b border-neutral-800" style={{background: BRAND.panel}}>
      <div className="flex-1 flex items-center gap-3 bg-[#111] rounded-xl px-3 h-10">
        <Search size={16} className="text-[#d6d0c9]"/>
        <input placeholder="Search…" className="bg-transparent outline-none text-sm w-full" style={{color: BRAND.text}}/>
      </div>
      <button className="hidden sm:inline-flex items-center gap-2 px-3 py-2 rounded-xl text-black" style={{background: BRAND.brand}}>
        <PlusCircle size={16}/> New Booking
      </button>
      <img src="/apple-touch-icon.png" alt="avatar" className="h-9 w-9 rounded-full border border-[#242424]"/>
    </header>
  );
}

function StatCard({label, value, delta, icon}){
  return (
    <div className="rounded-2xl p-4 border border-neutral-800" style={{background: BRAND.card}}>
      <div className="flex items-center justify-between">
        <span className="text-sm" style={{color: BRAND.subtext}}>{label}</span>
        <div style={{color: '#ff4da3'}}>{icon}</div>
      </div>
      <div className="mt-2 text-2xl font-semibold" style={{color: BRAND.text}}>{value}</div>
      <div className="text-xs mt-1" style={{color: BRAND.subtext}}>{delta} vs last week</div>
    </div>
  );
}

function Card({title, children, right}){
  return (
    <section className="rounded-2xl p-4 border border-neutral-800" style={{background: BRAND.card}}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold" style={{color: BRAND.text}}>{title}</h3>
        {right}
      </div>
      {children}
    </section>
  );
}

function DashboardInner(){
  return (
    <div style={{background: BRAND.bg, color: BRAND.text}} className="min-h-screen">
      <div className="flex">
        <Sidebar/>
        <div className="flex-1">
          <Topbar/>
          <main className="px-4 md:px-8 py-6 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
              {statCards.map((c,i)=> <StatCard key={i} {...c}/>) }
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Card title="Inquiries per Month">
                <div style={{width: '100%', height: 250}}>
                  <ResponsiveContainer>
                    <BarChart data={inquiriesPerMonth}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                      <XAxis dataKey="m" stroke="#aaa"/>
                      <YAxis stroke="#aaa"/>
                      <Tooltip contentStyle={{background: BRAND.panel, border: `1px solid ${BRAND.border}`, color: BRAND.text}}/>
                      <Bar dataKey="v" fill={BRAND.brand} radius={[8,8,0,0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </Card>

              <Card title="Income per Month">
                <div style={{width: '100%', height: 250}}>
                  <ResponsiveContainer>
                    <AreaChart data={incomePerMonth}>
                      <defs>
                        <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={BRAND.brand} stopOpacity={0.8}/>
                          <stop offset="95%" stopColor={BRAND.brand} stopOpacity={0.1}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                      <XAxis dataKey="m" stroke="#aaa"/>
                      <YAxis stroke="#aaa"/>
                      <Tooltip contentStyle={{background: BRAND.panel, border: `1px solid ${BRAND.border}`, color: BRAND.text}}/>
                      <Area type="monotone" dataKey="v" stroke={BRAND.brand} fill="url(#g1)" strokeWidth={2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </Card>

              <Card title="Inquiry Source Breakdown">
                <div style={{width: '100%', height: 250}}>
                  <ResponsiveContainer>
                    <PieChart>
                      <Tooltip contentStyle={{background: BRAND.panel, border: `1px solid ${BRAND.border}`, color: BRAND.text}}/>
                      <Legend verticalAlign="bottom" height={36} wrapperStyle={{color: BRAND.subtext}}/>
                      <Pie data={sourceBreakdown} dataKey="v" nameKey="name" innerRadius={60} outerRadius={90} paddingAngle={4}>
                        {sourceBreakdown.map((_, i) => (
                          <Cell key={i} fill={pieColors[i % pieColors.length]} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </Card>
            </div>

            <Card title="Today's Appointments" right={<button className="text-xs px-3 py-1 rounded-lg" style={{background: BRAND.brand, color: '#000'}}>Export</button>}>
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="text-left border-b border-neutral-800" style={{color: BRAND.subtext}}>
                      <th className="py-2 pr-4">Time</th>
                      <th className="py-2 pr-4">Client</th>
                      <th className="py-2 pr-4">Service</th>
                      <th className="py-2 pr-4">Staff</th>
                      <th className="py-2 pr-4">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['09:30', 'Anaya K.', 'Classic Blowout', 'Riya', 'Booked'],
                      ['10:30', 'Meera S.', 'Gel Manicure', 'Nia', 'Seated'],
                      ['11:30', 'Zara P.', 'Brow Shaping', 'Aarav', 'Booked'],
                      ['12:15', 'Ishaan T.', 'Makeup Trial', 'Riya', 'Confirmed'],
                    ].map((r, i) => (
                      <tr key={i} className="border-b border-neutral-900/60 hover:bg-neutral-900/40">
                        {r.map((c, j) => <td key={j} className="py-3 pr-4">{c}</td>)}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

          </main>
        </div>
      </div>
    </div>
  )
}

export default function AdminDashboard(){
  return (
    <AdminGate>
      <DashboardInner/>
    </AdminGate>
  )
}
