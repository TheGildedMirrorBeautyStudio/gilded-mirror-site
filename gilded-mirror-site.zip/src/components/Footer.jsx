import React from 'react'
export default function Footer(){
  return (
    <footer className="border-t border-neutral-800 mt-10">
      <div className="container py-8 text-sm flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
        <p>&copy; <span>{new Date().getFullYear()}</span> The Gilded Mirror Beauty Studio</p>
        <p className="opacity-70">Made with ♥ — Hosted on Netlify</p>
      </div>
    </footer>
  )
}
