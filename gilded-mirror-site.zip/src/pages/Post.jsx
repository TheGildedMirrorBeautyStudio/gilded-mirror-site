import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'
import { loadCollection } from '../lib/content'
import { useParams } from 'react-router-dom'

export default function Post(){
  const { slug } = useParams()
  const posts = loadCollection('/content/blog/*.md')
  const post = posts.find(p => p.slug === slug)
  if(!post){
    return (<><Header/><main className="container py-10">Not found</main><Footer/></>)
  }
  return (
    <>
      <Header/>
      <main className="container py-10">
        <h1 className="text-4xl font-bold">{post.title}</h1>
        <p className="opacity-70">{post.date?.slice(0,10)} • {post.author}</p>
        {post.cover && <img src={post.cover} alt="" className="mt-4 rounded-xl" />}
        <article className="prose prose-invert mt-6 max-w-none" dangerouslySetInnerHTML={{__html: post.content}}/>
      </main>
      <Footer/>
    </>
  )
}
