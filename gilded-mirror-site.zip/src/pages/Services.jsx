import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'
import { loadCollection } from '../lib/content'
import ServiceCard from '../components/ServiceCard'

export default function Services(){
  const services = loadCollection('/content/services/*.md')
  return (
    <>
      <Header/>
      <main className="container py-10">
        <h1 className="text-4xl font-bold mb-6">Services</h1>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map(s => <ServiceCard key={s.slug} service={s} />)}
        </div>
      </main>
      <Footer/>
    </>
  )
}
