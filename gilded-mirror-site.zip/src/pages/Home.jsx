import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'
import Hero from '../components/Hero'
import { loadCollection } from '../lib/content'

export default function Home(){
  const settings = loadCollection('/content/settings/*.md')[0] || {}
  const services = loadCollection('/content/services/*.md').slice(0,4)

  return (
    <>
      <Header/>
      <Hero heading={settings.hero_heading || 'Reflect Your Best Self'} sub={settings.hero_subtext || 'Luxury beauty services with a personal touch.'} />
      <section className="container py-10">
        <h2 className="text-2xl font-bold mb-4">Featured Services</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map(s=> (
            <a href="/services" key={s.slug} className="card p-5 hover:shadow-soft transition-shadow">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-xl font-semibold">{s.title}</h3>
                  <p className="text-sm opacity-70">{s.category} • {s.duration} min</p>
                  <p className="mt-1 font-semibold">{s.price}</p>
                </div>
                {s.image && <img src={s.image} alt="" className="h-20 w-20 object-cover rounded-xl"/>}
              </div>
            </a>
          ))}
        </div>
      </section>

      <section className="container py-10">
        <h2 className="text-2xl font-bold mb-4">Visit Us</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="card p-5">
            <p><strong>Phone:</strong> {settings.phone || '+1 (555) 123-4567'}</p>
            <p><strong>Email:</strong> {settings.email || 'hello@example.com'}</p>
            <p><strong>Address:</strong> {settings.address || '123 Vanity Lane, City'}</p>
            <a href="/book" className="btn btn-primary mt-4 inline-block">Book Now</a>
          </div>
          <div className="card p-2">
            <iframe title="map" src="https://maps.google.com/maps?q=New%20York&t=&z=13&ie=UTF8&iwloc=&output=embed" className="w-full h-64 rounded-xl"></iframe>
          </div>
        </div>
      </section>
      <Footer/>
    </>
  )
}
