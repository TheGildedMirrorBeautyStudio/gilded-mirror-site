---
hero_heading: Reflect Your Best Self
hero_subtext: Luxury beauty services with a personal touch.
phone: "+1 (555) 123-4567"
email: "hello@gildedmirror.example"
address: "123 Vanity Lane, Aura District, City"
---