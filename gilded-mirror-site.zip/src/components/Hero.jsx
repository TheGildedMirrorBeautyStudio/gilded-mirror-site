import React from 'react'
import { Link } from 'react-router-dom'

export default function Hero({heading, sub}){
  return (
    <section className="container py-16 md:py-24 text-center">
      <h1 className="font-display text-4xl md:text-6xl font-bold leading-tight">{heading}</h1>
      <p className="mt-4 text-lg opacity-90">{sub}</p>
      <div className="mt-8 flex items-center justify-center gap-4">
        <Link to="/book" className="btn btn-primary">Book Now</Link>
        <Link to="/services" className="btn border border-neutral-700">Explore Services</Link>
      </div>
    </section>
  )
}
