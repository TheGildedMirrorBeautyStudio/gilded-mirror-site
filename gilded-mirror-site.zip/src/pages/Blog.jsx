import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'
import { loadCollection } from '../lib/content'
import { Link } from 'react-router-dom'

export default function Blog(){
  const posts = loadCollection('/content/blog/*.md')
  return (
    <>
      <Header/>
      <main className="container py-10">
        <h1 className="text-4xl font-bold mb-6">Blog</h1>
        <div className="space-y-6">
          {posts.map(p => (
            <article key={p.slug} className="card p-5">
              <h2 className="text-2xl font-semibold"><Link to={`/blog/${p.slug}`}>{p.title}</Link></h2>
              <p className="opacity-70">{p.date?.slice(0,10)} • {p.author}</p>
              {p.cover && <img src={p.cover} alt="" className="mt-3 rounded-xl" />}
              <p className="mt-3 opacity-90">{p.excerpt}</p>
              <Link to={`/blog/${p.slug}`} className="underline mt-2 inline-block">Read more</Link>
            </article>
          ))}
        </div>
      </main>
      <Footer/>
    </>
  )
}
