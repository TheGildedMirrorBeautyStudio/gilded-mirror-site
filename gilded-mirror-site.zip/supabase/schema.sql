
-- Basic schema for Gilded Mirror bookings
create table if not exists clients (
  id uuid primary key default gen_random_uuid(),
  name text,
  email text unique,
  phone text,
  created_at timestamptz default now()
);

create table if not exists appointments (
  id uuid primary key default gen_random_uuid(),
  service_title text,
  service_slug text,
  service_duration int,
  service_price text,
  staff_name text,
  start timestamptz not null,
  end timestamptz not null,
  client_id uuid references clients(id) on delete set null,
  customer_name text,
  customer_email text,
  customer_phone text,
  status text default 'booked',
  source text default 'web',
  created_at timestamptz default now()
);

-- Indexes for faster lookups
create index if not exists idx_appts_start on appointments(start);
create index if not exists idx_appts_client on appointments(client_id);
