---
title: Classic Blowout
slug: classic-blowout
category: Hair
price: $49
duration: 45
image: /uploads/example-blowout.jpg
featured: true
---
A timeless, voluminous finish that lasts.