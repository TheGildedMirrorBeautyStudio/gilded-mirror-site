import React, { useEffect, useMemo, useState } from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'
import { loadCollection } from '../lib/content'

function formatDate(date){ return date.toISOString().slice(0,10) }
function addMinutes(dt, mins){ return new Date(dt.getTime() + mins*60000) }
function timeStr(dt){ return dt.toTimeString().slice(0,5) }

export default function Booking(){
  const services = loadCollection('/content/services/*.md')
  const [serviceSlug, setServiceSlug] = useState(services[0]?.slug || '')
  const service = useMemo(()=> services.find(s => s.slug === serviceSlug), [serviceSlug, services])

  const [date, setDate] = useState(formatDate(new Date(Date.now()+24*60*60*1000)))
  const [slots, setSlots] = useState([])
  const [selectedTime, setSelectedTime] = useState('')

  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')

  const businessHours = { start: '09:00', end: '19:00' } // simple example
  const buffer = 10

  useEffect(()=>{
    // Generate slots (basic) and remove any that overlap with existing bookings from function
    const d = new Date(date + 'T00:00:00')
    const [sh, sm] = businessHours.start.split(':').map(Number)
    const [eh, em] = businessHours.end.split(':').map(Number)
    let cur = new Date(d); cur.setHours(sh, sm, 0, 0)
    const end = new Date(d); end.setHours(eh, em, 0, 0)
    const step = (service?.duration || 30) + buffer
    let s = []
    while(addMinutes(cur, service?.duration || 30) <= end){
      s.push(new Date(cur))
      cur = addMinutes(cur, step)
    }
    setSlots(s)
  }, [date, serviceSlug])

  async function submitBooking(){
    const payload = {
      service: { slug: service.slug, title: service.title, duration: service.duration, price: service.price },
      staff: { id: null, name: "Any" },
      start: new Date(date + 'T' + selectedTime + ':00').toISOString(),
      end: addMinutes(new Date(date + 'T' + selectedTime + ':00'), service.duration || 30).toISOString(),
      customer: { name, email, phone },
      source: 'web',
    }
    const res = await fetch('/.netlify/functions/bookings-create', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    })
    const data = await res.json()
    if(res.ok){
      alert('Booked! Check your email for confirmation.')
      window.location.href = '/'
    } else {
      alert('Could not create booking: ' + data.message)
    }
  }

  return (
    <>
      <Header/>
      <main className="container py-10">
        <h1 className="text-4xl font-bold mb-6">Book an Appointment</h1>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Step 1: Service */}
          <section className="card p-5">
            <h2 className="font-semibold mb-3">1) Choose a Service</h2>
            <select value={serviceSlug} onChange={e=>setServiceSlug(e.target.value)} className="w-full bg-ink border border-neutral-700 rounded-xl p-2">
              {services.map(s => <option key={s.slug} value={s.slug}>{s.title} — {s.duration} min</option>)}
            </select>
          </section>

          {/* Step 2: Date & Time */}
          <section className="card p-5">
            <h2 className="font-semibold mb-3">2) Pick a Date & Time</h2>
            <input type="date" value={date} onChange={e=>setDate(e.target.value)} className="w-full bg-ink border border-neutral-700 rounded-xl p-2"/>
            <div className="mt-3 grid grid-cols-3 gap-2 max-h-48 overflow-y-auto">
              {slots.map(s => {
                const t = timeStr(s)
                return <button key={t} onClick={()=>setSelectedTime(t)} className={'p-2 rounded-xl border ' + (selectedTime===t? 'bg-brand text-black border-brand':'border-neutral-700')}>{t}</button>
              })}
            </div>
          </section>

          {/* Step 3: Your details */}
          <section className="card p-5">
            <h2 className="font-semibold mb-3">3) Your Details</h2>
            <input placeholder="Name" className="w-full bg-ink border border-neutral-700 rounded-xl p-2 mb-2" value={name} onChange={e=>setName(e.target.value)} />
            <input placeholder="Email" className="w-full bg-ink border border-neutral-700 rounded-xl p-2 mb-2" value={email} onChange={e=>setEmail(e.target.value)} />
            <input placeholder="Phone" className="w-full bg-ink border border-neutral-700 rounded-xl p-2 mb-2" value={phone} onChange={e=>setPhone(e.target.value)} />
            <button className="btn btn-primary mt-2 w-full" disabled={!selectedTime || !name || !email} onClick={submitBooking}>Confirm Booking</button>
            <p className="text-xs opacity-70 mt-2">You will receive a confirmation email with a calendar invite.</p>
          </section>
        </div>
      </main>
      <Footer/>
    </>
  )
}
