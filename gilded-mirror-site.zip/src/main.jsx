import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './index.css'

import Home from './pages/Home.jsx'
import Services from './pages/Services.jsx'
import Blog from './pages/Blog.jsx'
import Post from './pages/Post.jsx'
import Contact from './pages/Contact.jsx'
import Booking from './pages/Booking.jsx'
import AdminDashboard from './pages/admin/AdminDashboard.jsx'

const router = createBrowserRouter([
  { path: '/', element: <Home /> },
  { path: '/services', element: <Services /> },
  { path: '/blog', element: <Blog /> },
  { path: '/blog/:slug', element: <Post /> },
  { path: '/contact', element: <Contact /> },
  { path: '/book', element: <Booking /> },
  { path: '/gold-admin-mirror-7f3a', element: <AdminDashboard /> },
])

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>,
)
