import React from 'react'
import { Link, NavLink } from 'react-router-dom'

export default function Header(){
  return (
    <header className="sticky top-0 z-40 bg-ink/80 backdrop-blur border-b border-neutral-800">
      <div className="container flex items-center h-16 gap-6">
        <Link to="/" className="flex items-center gap-3">
          <img src="/apple-touch-icon.png" className="h-8 w-8 rounded-full" alt="logo"/>
          <span className="font-display font-bold text-lg">The Gilded Mirror</span>
        </Link>
        <nav className="ml-auto flex items-center gap-5">
          {['/','/services','/blog','/book','/contact'].map((p,i)=>{
            const label = ['Home','Services','Blog','Book','Contact'][i]
            return <NavLink key={p} to={p} className={({isActive})=>`text-sm ${isActive? 'text-brand': 'text-cream/80 hover:text-cream'}`}>{label}</NavLink>
          })}
          <a href="/gold-admin-mirror-7f3a/" className="text-xs opacity-0">admin</a>
        </nav>
      </div>
    </header>
  )
}
