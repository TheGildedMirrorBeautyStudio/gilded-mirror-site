import React from 'react'

export default function ServiceCard({service}){
  return (
    <article className="card p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-xl font-semibold">{service.title}</h3>
          <p className="text-sm opacity-70">{service.category} • {service.duration} min</p>
          <p className="mt-1 font-semibold">{service.price}</p>
        </div>
        {service.image && <img src={service.image} alt="" className="h-20 w-20 object-cover rounded-xl"/>}
      </div>
      {service.content && <div className="mt-3 opacity-90 text-sm" dangerouslySetInnerHTML={{__html: service.content}}/>}
      <a href="/book" className="btn btn-primary mt-4">Book Now</a>
    </article>
  )
}
